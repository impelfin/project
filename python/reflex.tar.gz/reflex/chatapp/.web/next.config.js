module.exports = {basePath: "", compress: true, reactStrictMode: true, trailingSlash: true};
